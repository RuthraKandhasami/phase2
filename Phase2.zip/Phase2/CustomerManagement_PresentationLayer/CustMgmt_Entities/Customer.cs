﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustMgmt_Entities
{
    public class Customer
    {
        //Declaring variables and its properties
        public int CustId { get; set; }
        public string CustName { get; set; }
        public string City { get; set; }
        public int Age { get; set; }
        public string PhoneNo { get; set; }
        public string PinCode { get; set; }
    }
}
