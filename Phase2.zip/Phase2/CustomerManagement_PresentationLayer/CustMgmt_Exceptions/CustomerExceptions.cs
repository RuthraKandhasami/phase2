﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustMgmt_Exceptions
{
    public class CustomerExceptions:ApplicationException//Inheriting System exception
    {
        public CustomerExceptions()//Base Class Exception
          : base()
        {
        }

        public CustomerExceptions(string message)//Derived class exception
            : base(message)
        {
        }
        public CustomerExceptions(string message, CustomerExceptions innerException)
            : base(message, innerException)
        {
        }
    }
}
