﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CustMgmt_BAL;
using CustMgmt_Entities;
using CustMgmt_Exceptions;
using CustMgmt_DataAccessLayer;

namespace CustomerManagement_PresentationLayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Grid_Menu.Visibility = Visibility.Hidden;
            Hide();
            //GetAllCust();
        }

        public void Hide()
        {

            Grid_body.Visibility = Visibility.Hidden;
            Add_Grid_body.Visibility = Visibility.Hidden;
            SUbtnTemp.Visibility = Visibility.Hidden;
            dgCustomers.Visibility = Visibility.Hidden;

            Control_btnInsert.Visibility = Visibility.Hidden;
            Control_btnSearchId.Visibility = Visibility.Hidden;
            Control_btnSearchName.Visibility = Visibility.Hidden;
            Control_btnUpdateId.Visibility = Visibility.Hidden;
            Control_btnUpdateName.Visibility = Visibility.Hidden;
            Control_btnDeleteId.Visibility = Visibility.Hidden;
            Control_btnDeleteName.Visibility = Visibility.Hidden;
            txtid.IsEnabled = true;
        }

        private void InsertCustomer()
        {
            int result;
            try

            {
                int id, custage;
                string name, ccity, phoneno, pincode;
                Customer cust = new Customer();
                //id = Convert.ToInt32(custid.Text);

                try
                {
                    custage = Convert.ToInt32(Add_txtage.Text);
                    cust.Age = custage;
                }
                catch (Exception)
                {

                    MessageBox.Show("Invalid or empty value for Age");
                }
                name = Add_txtname.Text;
                cust.CustName = name;

                ccity = Add_txtcity.Text;
                cust.City = ccity;

                phoneno = Add_txtphoneno.Text;
                cust.PhoneNo = phoneno;

                pincode = Add_txtpincode.Text;
                cust.PinCode = pincode;


                //CustId = id,

                result = BAL.AddCustomerBL(cust);
                GetAllCust();

                if (!(result.ToString() == null))
                {
                    MessageBox.Show("Customer Record Added Sucessfully for the ID : " + result);
                }
                else
                {
                    MessageBox.Show("Customer Record couldn't be Added!!!");
                }
            }
            catch (CustomerExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void UpdateCustomerById()
        {
            
            bool result;
            try
            {
                int id, custage;
                string name, ccity, phoneno, pincode;

                id = Convert.ToInt32(txtid.Text);
                custage = Convert.ToInt32(txtage.Text);
                name = txtname.Text;
                ccity = txtcity.Text;
                phoneno = txtphoneno.Text;
                pincode = txtpincode.Text;

                Customer cust = new Customer()
                {
                    CustId = id,
                    CustName = name,
                    City = ccity,
                    Age = custage,
                    PhoneNo = phoneno,
                    PinCode = pincode
                };
                result = BAL.UpdateCustomerIdBL(cust);
                GetAllCust();
                if (result == true)
                {
                    MessageBox.Show("Customer Record Updated Sucessfully!!!");
                }
                else
                {
                    MessageBox.Show("Customer Record couldn't be Updated!!!");
                }
            }
            catch (CustomerExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void UpdateCustomerByName()
        {
            bool result;
            try
            {
                int id, custage;
                string name, ccity, phoneno, pincode;

                id = Convert.ToInt32(txtid.Text);
                custage = Convert.ToInt32(txtage.Text);
                name = txtname.Text;
                ccity = txtcity.Text;
                phoneno = txtphoneno.Text;
                pincode = txtpincode.Text;

                Customer cust = new Customer()
                {
                    CustId = id,
                    CustName = name,
                    City = ccity,
                    Age = custage,
                    PhoneNo = phoneno,
                    PinCode = pincode
                };
                result = BAL.UpdateCustomerNameBL(cust);
                GetAllCust();
                if (result == true)
                {
                    MessageBox.Show("Customer Record Updated Sucessfully!!!");
                }
                else
                {
                    MessageBox.Show("Customer Record couldn't be Updated!!!");
                }
            }
            catch (CustomerExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void DeleteCustomerById()
        {
            bool result;
            try

            {
                int id;


                id = Convert.ToInt32(txtid.Text);


                Customer cust = new Customer()
                {
                    CustId = id,

                };
                result = BAL.DeleteCustomerIdBL(cust);
                GetAllCust();

                if (result == true)
                {
                    MessageBox.Show("Customer Removed Sucessfully!!!");
                }
                else
                {
                    MessageBox.Show("Customer Record couldn't be Removed!!!");
                }
            }
            catch (CustomerExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void DeleteCustomerByName()
        {
            bool result;
            try

            {
                string name;


                name = txtname.Text;


                Customer cust = new Customer()
                {
                    CustName = name,

                };
                result = BAL.DeleteCustomerNameBL(cust);
                GetAllCust();

                if (result == true)
                {
                    MessageBox.Show("Customer Removed Sucessfully!!!");
                }
                else
                {
                    MessageBox.Show("Customer Record couldn't be Removed!!!");
                }
            }
            catch (CustomerExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void SearchCustomerById()
        {
            
            try
            {
                int id;
                Customer result;

                id = Convert.ToInt32(txtid.Text);
                result = BAL.SearchCustomerIdBL(id);
                
                if (result != null)
                {

                    txtname.Text = result.CustName;
                    txtcity.Text = result.City;
                    txtage.Text = result.Age.ToString();
                    txtphoneno.Text = result.PhoneNo;
                    txtpincode.Text = result.PinCode;

                    MessageBox.Show("Required Customer details displayed");
                }
            }
            catch (CustomerExceptions ex)

            {
                MessageBox.Show(ex.Message);
            }

        }

        private void SearchCustomerByName()
        {
            try
            {
                string name;
                Customer result;

                name = txtname.Text;
                result = BAL.SearchCustomerNameBL(name);
                
                if (result != null)
                {

                    txtid.Text = result.CustId.ToString();
                    txtcity.Text = result.City;
                    txtage.Text = result.Age.ToString();
                    txtphoneno.Text = result.PhoneNo;
                    txtpincode.Text = result.PinCode;

                    MessageBox.Show("Required Customer details displayed");
                }
            }
            catch (CustomerExceptions ex)

            {
                MessageBox.Show(ex.Message);
            }

        }

        private void GetAllCust()
        {
            try
            {
                List<Customer> custom;
                custom = BAL.GetCustomerBL();
                if (custom != null)
                {
                    dgCustomers.ItemsSource = custom;

                }
                else
                {
                    MessageBox.Show("No Record Available!!!");
                }
            }
            catch (CustomerExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Clear()
        {
            txtid.Clear();
            txtname.Clear();
            txtage.Clear();
            txtphoneno.Clear();
            txtpincode.Clear();
            txtcity.Clear();
        }

        private void Control_btnInsert_Click(object sender, RoutedEventArgs e)
        {
            InsertCustomer();
            Clear();
        }

        private void Control_btnSearchId_Click(object sender, RoutedEventArgs e)
        {
            SearchCustomerById();
           
        }

        private void Control_btnSearchName_Click(object sender, RoutedEventArgs e)
        {
            SearchCustomerByName();
            
        }

        private void Control_btnUpdateId_Click(object sender, RoutedEventArgs e)
        {
            UpdateCustomerById();
            Clear();
        }

        private void Control_btnUpdateName_Click(object sender, RoutedEventArgs e)
        {
            UpdateCustomerByName();
            Clear();
        }

        private void Control_btnDeleteId_Click(object sender, RoutedEventArgs e)
        {
            DeleteCustomerById();
        }

        private void Control_btnDeleteName_Click(object sender, RoutedEventArgs e)
        {
            DeleteCustomerByName();
            Clear();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            Hide();
            Add_Grid_body.Visibility = Visibility.Visible;
            
            
            Control_btnInsert.Visibility = Visibility.Visible;
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            Hide();
            Grid_body.Visibility = Visibility.Visible;
            Control_btnSearchId.Visibility = Visibility.Visible;
            Control_btnSearchName.Visibility = Visibility.Visible;
            
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            Hide();
            SUbtnTemp.Visibility = Visibility.Visible;
               
            Grid_body.Visibility = Visibility.Visible;
           
            Control_btnUpdateId.Visibility = Visibility.Visible;
            Control_btnUpdateName.Visibility = Visibility.Visible;
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {

            Hide();
            SUbtnTemp.Visibility = Visibility.Visible;
            Grid_body.Visibility = Visibility.Visible;
            Control_btnDeleteId.Visibility = Visibility.Visible;
            Control_btnDeleteName.Visibility = Visibility.Visible;
        }

        private void BtnViewAll_Click(object sender, RoutedEventArgs e)
        {
            Hide();
            dgCustomers.Visibility = Visibility.Visible;
            GetAllCust();
        }
        private void StackPanel_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Grid_Menu.Visibility = Visibility.Visible;
        }

        private void ImageBrush_MouseDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void Grid_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Grid_Menu.Visibility = Visibility.Visible;
        }

        private void SUbtnTemp_Click(object sender, RoutedEventArgs e)
        {
            txtid.IsEnabled = false;
            SearchCustomerById();
        }
    }
    
}
