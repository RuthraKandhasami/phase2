﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CustMgmt_Entities;
using CustMgmt_Exceptions;
using CustMgmt_DataAccessLayer;

namespace CustMgmt_BAL
{
    public class BAL
    {
        private static bool ValidateCustomer(Customer customer)
        {
            StringBuilder sb = new StringBuilder();
            bool validCustomer = true;

            if (customer.CustName == string.Empty)
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Customer Name Required!!!");

            }

            if (customer.City == string.Empty)
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Customer City Required!!!");

            }

            if (customer.Age <= 0)
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Customer should be greater than 0");

            }

            if (customer.PhoneNo == string.Empty)
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Phone Number Required!!!");

            }

            if (customer.PhoneNo.Length < 10)
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Required 10 Digit Contact Number!!!");
            }

            if (customer.PinCode == string.Empty)
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Customer Pin Code Required!!!");

            }

            if (customer.PinCode.Length < 6)
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Required 6 Digit Pin Code!!!");
            }

            if (validCustomer == false)
                throw new CustomerExceptions(sb.ToString());
            return validCustomer;
        }

        public static int AddCustomerBL(Customer customer)
        {
            int CustomerAdded=0;

            try
            {
                if(ValidateCustomer(customer))
                {
                    CustomerDAL objDAL = new CustomerDAL();
                    CustomerAdded = objDAL.AddCustDAL(customer);
                }
                
            }
            catch (CustomerExceptions ex)
            {
                throw ex;
            }
            return CustomerAdded;
        }
        public static bool UpdateCustomerIdBL(Customer customer)
        {
            bool CustomerUpdated = false;
            try
            {
                if (ValidateCustomer(customer))
                {
                    CustomerDAL objDAL = new CustomerDAL();
                    CustomerUpdated = objDAL.UpdateCustIdDAL(customer);
                }
               
            }
            catch (CustomerExceptions ex)
            {
                throw ex;
            }
            return CustomerUpdated;
        }
        public static bool UpdateCustomerNameBL(Customer customer)
        {
            bool CustomerUpdated = false;
            try
            {
                if (ValidateCustomer(customer))
                {
                    CustomerDAL objDAL = new CustomerDAL();
                    CustomerUpdated = objDAL.UpdateCustNameDAL(customer);
                }

            }
            catch (CustomerExceptions ex)
            {
                throw ex;
            }
            return CustomerUpdated;
        }
        public static bool DeleteCustomerIdBL(Customer customer)
        {
            bool CustomerDeleted = false;
            try
            {
                CustomerDAL objDAL = new CustomerDAL();
                CustomerDeleted = objDAL.DeleteCustIdDAL(customer);
            }
            catch (CustomerExceptions ex)
            {
                throw ex;
            }
            return CustomerDeleted;
        }
        public static bool DeleteCustomerNameBL(Customer customer)
        {
            bool CustomerDeleted = false;
            try
            {
                CustomerDAL objDAL = new CustomerDAL();
                CustomerDeleted = objDAL.DeleteCustNameDAL(customer);
            }
            catch (CustomerExceptions ex)
            {
                throw ex;
            }
            return CustomerDeleted;
        }
        public static Customer SearchCustomerIdBL(int custoid)
        {
            Customer SearchCustomer = null;
            try
            {
                CustomerDAL objDAL = new CustomerDAL();
                SearchCustomer = objDAL.SearchCustIdDAL(custoid);
            }
            catch (CustomerExceptions ex)
            {
                throw ex;
            }
            return SearchCustomer;
        }
        public static Customer SearchCustomerNameBL(string custname)
        {
            Customer SearchCustomer = null;
            try
            {
                CustomerDAL objDAL = new CustomerDAL();
                SearchCustomer = objDAL.SearchCustNameDAL(custname);
            }
            catch (CustomerExceptions ex)
            {
                throw ex;
            }
            return SearchCustomer;
        }
        public static List<Customer> GetCustomerBL()
        {
            List<Customer> GetAllCustomers = null;
            try
            {
                CustomerDAL objDAL = new CustomerDAL();
                GetAllCustomers = objDAL.GetCustomerDAL();
            }
            catch (CustomerExceptions ex)
            {
                throw ex;
            }
            return GetAllCustomers;
        }

    }

}
