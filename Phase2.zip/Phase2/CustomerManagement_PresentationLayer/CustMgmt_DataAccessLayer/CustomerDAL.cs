﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CustMgmt_Entities;
using CustMgmt_Exceptions;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
namespace CustMgmt_DataAccessLayer
{
    public class CustomerDAL
    {
        SqlConnection con = null;//Creating connection object
        SqlCommand cmd = null;//Creating command object
        SqlDataReader dr = null;//Creating datareader object
        public int AddCustDAL(Customer cust)//
        {
            int CustomerAdded;
            try
            {
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);//Connection String
                cmd = new SqlCommand("[24699].[Insert_Customer]", con);//Sql Command
                cmd.CommandType = CommandType.StoredProcedure;
                SqlParameter sqlParameter_id = new SqlParameter("@C_Id", SqlDbType.Int);
                sqlParameter_id.Direction = ParameterDirection.Output;
                cmd.Parameters.Add(sqlParameter_id);
                SqlParameter sqlParameter_Name = new SqlParameter("@C_Name", cust.CustName);
                SqlParameter sqlParameter_city = new SqlParameter("@C_City", cust.City);
                SqlParameter sqlParameter_age = new SqlParameter("@C_Age", cust.Age);
                SqlParameter sqlParameter_phone = new SqlParameter("@C_PNo", cust.PhoneNo);
                SqlParameter sqlParameter_pin = new SqlParameter("@C_PinNo", cust.PinCode);


                cmd.Parameters.Add(sqlParameter_Name);
                cmd.Parameters.Add(sqlParameter_city);
                cmd.Parameters.Add(sqlParameter_age);
                cmd.Parameters.Add(sqlParameter_phone);
                cmd.Parameters.Add(sqlParameter_pin);

                con.Open();//Connection open
                cmd.ExecuteNonQuery();

                CustomerAdded = Convert.ToInt32(cmd.Parameters["@C_Id"].Value);
            }
            catch (SqlException ex)//To catch the exception
            {
                throw new CustomerExceptions(ex.Message);//To throw the exception
            }
            finally
            {
                con.Close();//Connection close
            }
            return CustomerAdded;

        }
        public bool UpdateCustIdDAL(Customer cust)
        {
            bool CustomerUpdated = false;
            try
            {
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
                cmd = new SqlCommand("[24699].[Update_Customer]", con);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlParameter sqlParameter_id = new SqlParameter("@C_Id", cust.CustId);
                SqlParameter sqlParameter_Name = new SqlParameter("@C_Name", cust.CustName);
                SqlParameter sqlParameter_city = new SqlParameter("@C_City", cust.City);
                SqlParameter sqlParameter_age = new SqlParameter("@C_Age", cust.Age);
                SqlParameter sqlParameter_phone = new SqlParameter("@C_PNo", cust.PhoneNo);
                SqlParameter sqlParameter_pin = new SqlParameter("@C_PinNo", cust.PinCode);

                cmd.Parameters.Add(sqlParameter_id);
                cmd.Parameters.Add(sqlParameter_Name);
                cmd.Parameters.Add(sqlParameter_city);
                cmd.Parameters.Add(sqlParameter_age);
                cmd.Parameters.Add(sqlParameter_phone);
                cmd.Parameters.Add(sqlParameter_pin);

                con.Open();
                cmd.ExecuteNonQuery();
                CustomerUpdated = true;
            }
            catch (SqlException ex)//To catch the exception
            {
                throw new CustomerExceptions(ex.Message);//To throw the exception
            }
            finally
            {
                con.Close();
            }
            return CustomerUpdated;
        }
        public bool UpdateCustNameDAL(Customer cust)
        {
            bool CustomerUpdated = false;
            try
            {
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
                cmd = new SqlCommand("[24699].[UpdateCustomerName]", con);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlParameter sqlParameter_id = new SqlParameter("@C_Id", cust.CustId);
                SqlParameter sqlParameter_Name = new SqlParameter("@C_Name", cust.CustName);
                SqlParameter sqlParameter_city = new SqlParameter("@C_City", cust.City);
                SqlParameter sqlParameter_age = new SqlParameter("@C_Age", cust.Age);
                SqlParameter sqlParameter_phone = new SqlParameter("@C_PNo", cust.PhoneNo);
                SqlParameter sqlParameter_pin = new SqlParameter("@C_PinNo", cust.PinCode);

                cmd.Parameters.Add(sqlParameter_id);
                cmd.Parameters.Add(sqlParameter_Name);
                cmd.Parameters.Add(sqlParameter_city);
                cmd.Parameters.Add(sqlParameter_age);
                cmd.Parameters.Add(sqlParameter_phone);
                cmd.Parameters.Add(sqlParameter_pin);

                con.Open();
                cmd.ExecuteNonQuery();
                CustomerUpdated = true;
            }
            catch (SqlException ex)//To catch the exception
            {
                throw new CustomerExceptions(ex.Message);//To throw the exception
            }
            finally
            {
                con.Close();
            }
            return CustomerUpdated;
        }
        public bool DeleteCustIdDAL(Customer cust)
        {
            bool CustomerDeleted = false;
            try
            {
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
                cmd = new SqlCommand("[24699].[Delete_Customer]", con);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlParameter sqlParameter_id = new SqlParameter("@C_Id", cust.CustId);

                cmd.Parameters.Add(sqlParameter_id);


                con.Open();
                cmd.ExecuteNonQuery();
                CustomerDeleted = true;
            }
            catch (SqlException ex)//To catch the exception
            {
                throw new CustomerExceptions(ex.Message);//To throw the exception
            }
            finally
            {
                con.Close();
            }
            return CustomerDeleted;
        }
        public bool DeleteCustNameDAL(Customer cust)
        {
            bool CustomerDeleted = false;
            try
            {
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
                cmd = new SqlCommand("[24699].[Delete_Customer_Name]", con);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlParameter sqlParameter_name = new SqlParameter("@C_Name", cust.CustName);

                cmd.Parameters.Add(sqlParameter_name);


                con.Open();
                cmd.ExecuteNonQuery();
                CustomerDeleted = true;
            }
            catch (SqlException ex)//To catch the exception
            {
                throw new CustomerExceptions(ex.Message);//To throw the exception
            }
            finally
            {
                con.Close();
            }
            return CustomerDeleted;
        }
        public Customer SearchCustIdDAL(int custId)
        {
            Customer cust = null;
            try
            {
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
                cmd = new SqlCommand("[24699].[Search_Customer1]", con);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlParameter sqlParameter_id = new SqlParameter("@C_Id", SqlDbType.Int);
                SqlParameter sqlParameter_Name = new SqlParameter("@C_Name", SqlDbType.VarChar, 20);
                SqlParameter sqlParameter_city = new SqlParameter("@C_City", SqlDbType.VarChar, 20);
                SqlParameter sqlParameter_age = new SqlParameter("@C_Age", SqlDbType.Int);
                SqlParameter sqlParameter_phone = new SqlParameter("@C_PNo", SqlDbType.VarChar, 20);
                SqlParameter sqlParameter_pin = new SqlParameter("@C_PinNo", SqlDbType.VarChar, 20);

                sqlParameter_id.Direction = ParameterDirection.Input;
                sqlParameter_Name.Direction = ParameterDirection.Output;
                sqlParameter_city.Direction = ParameterDirection.Output;
                sqlParameter_age.Direction = ParameterDirection.Output;
                sqlParameter_phone.Direction = ParameterDirection.Output;
                sqlParameter_pin.Direction = ParameterDirection.Output;


                cmd.Parameters.Add(sqlParameter_id);
                cmd.Parameters.Add(sqlParameter_Name);
                cmd.Parameters.Add(sqlParameter_city);
                cmd.Parameters.Add(sqlParameter_age);
                cmd.Parameters.Add(sqlParameter_phone);
                cmd.Parameters.Add(sqlParameter_pin);
                sqlParameter_id.Value = custId;

                con.Open();
                cmd.ExecuteNonQuery();
                cust = new Customer();
                cust.CustId = custId;
                cust.CustName = sqlParameter_Name.Value.ToString();
                cust.City = sqlParameter_city.Value.ToString();
                cust.Age = Convert.ToInt32(sqlParameter_age.Value);
                cust.PhoneNo = sqlParameter_phone.Value.ToString();
                cust.PinCode = sqlParameter_pin.Value.ToString();

            }
            catch (SqlException ex)//To catch the exception
            {
                throw new CustomerExceptions(ex.Message);//To throw the exception
            }
            finally
            {
                con.Close();
            }
            return cust;

        }
        public Customer SearchCustNameDAL(string custName)
        {
            Customer cust=null;
            try
            {
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
                cmd = new SqlCommand("[24699].[Search_Customer_Name]", con);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlParameter sqlParameter_id = new SqlParameter("@C_Id", SqlDbType.Int);
                SqlParameter sqlParameter_Name = new SqlParameter("@C_Name", SqlDbType.VarChar, 20);
                SqlParameter sqlParameter_city = new SqlParameter("@C_City", SqlDbType.VarChar, 20);
                SqlParameter sqlParameter_age = new SqlParameter("@C_Age", SqlDbType.Int);
                SqlParameter sqlParameter_phone = new SqlParameter("@C_PNo", SqlDbType.VarChar, 20);
                SqlParameter sqlParameter_pin = new SqlParameter("@C_PinNo", SqlDbType.VarChar, 20);

                sqlParameter_Name.Direction = ParameterDirection.Input;
                sqlParameter_id.Direction = ParameterDirection.Output;
                sqlParameter_city.Direction = ParameterDirection.Output;
                sqlParameter_age.Direction = ParameterDirection.Output;
                sqlParameter_phone.Direction = ParameterDirection.Output;
                sqlParameter_pin.Direction = ParameterDirection.Output;


                cmd.Parameters.Add(sqlParameter_id);
                cmd.Parameters.Add(sqlParameter_Name);
                cmd.Parameters.Add(sqlParameter_city);
                cmd.Parameters.Add(sqlParameter_age);
                cmd.Parameters.Add(sqlParameter_phone);
                cmd.Parameters.Add(sqlParameter_pin);
                sqlParameter_Name.Value = custName;

                con.Open();
                cmd.ExecuteNonQuery();
                cust = new Customer();
                cust.CustName = custName;
                cust.CustId = Convert.ToInt32(sqlParameter_id.Value);
                cust.City = sqlParameter_city.Value.ToString();
                cust.Age = Convert.ToInt32(sqlParameter_age.Value);
                cust.PhoneNo = sqlParameter_phone.Value.ToString();
                cust.PinCode = sqlParameter_pin.Value.ToString();

            }
            catch (SqlException ex)//To catch the exception
            {
                throw new CustomerExceptions(ex.Message);//To throw the exception
            }
            finally
            {
                con.Close();
            }
            return cust;

        }
        public List<Customer> GetCustomerDAL()
        {
            List<Customer> customers = new List<Customer>();
            try
            {

                con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
                cmd = new SqlCommand("[24699].[List_Customer]", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Customer custom = new Customer();
                    custom.CustId = Convert.ToInt32(dr[0]);
                    custom.CustName = dr[1] as string;
                    custom.City = dr[2] as string;
                    custom.Age = Convert.ToInt32(dr[3]);
                    custom.PhoneNo = dr[4] as string;
                    custom.PinCode = dr[5] as string;
                    customers.Add(custom);
                }
            }
            catch (SqlException ex)//To catch the exception
            {
                throw new CustomerExceptions(ex.Message);//To throw the exception
            }
            finally
            {
                con.Close();
            }
            return customers;
        }
    }
}
